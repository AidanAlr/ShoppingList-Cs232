public class ClothingItem extends Item {

    public ClothingItem(String description, int priority, double cost) {
        super(description, priority, cost);
    }
}
