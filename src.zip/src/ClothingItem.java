public class ClothingItem extends ItemParent {

    public ClothingItem(String description, int priority, double cost) {
        super(description, priority, cost);
    }
}
