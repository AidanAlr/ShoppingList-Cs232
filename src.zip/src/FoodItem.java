public class FoodItem extends ItemParent {
    public FoodItem(String des, int pri, double cos) {
        super(des, pri, cos);
    }


}
