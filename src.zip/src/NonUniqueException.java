public class NonUniqueException extends Exception{

    public NonUniqueException(){
        System.out.println("Oops! you entered a non unique item!");
    }

}
