public class HomeItem extends Item {
    public HomeItem(String description, int priority, double cost) {
        super(description, priority, cost);
    }

}
