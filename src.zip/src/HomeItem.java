public class HomeItem extends ItemParent {
    public HomeItem(String des, int pri, double cos) {
        super(des, pri, cos);
    }

}
